<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>

<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt"%>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
<title>Bootstrap 101 Template</title>

<!-- Bootstrap -->
<link href="../css/bootstrap.min.css" rel="stylesheet">

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

<style type="text/css">
#photo {
	width: 450px;
	height: 350px;
	margin: auto;
	position: relative;
	text-align: center;
}

#btnGroup {
	margin: auto;
	position: relative;
	text-align: center;
}
</style>
</head>
<body>
	<h1>글 정보</h1>
	<hr>
	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
	<script src="../js/jquery.js"></script>
	<!-- Include all compiled plugins (below), or include individual files as needed -->
	<script src="../js/bootstrap.min.js"></script>
	<script type="text/javascript">
			$(function($) {
				var idx = $("#idx").val();
				 $("#edit").click(function() {
					 location.reload();
					$("#form1").attr("action","../board/edit?idx="+idx);
					$("#form1").submit();
				}); 
				$("#remove").click(function() {
					$("#form1").attr("action","../board/delete?idx="+idx);
					$("#form1").submit();
				});
			});
		</script>

	
	
	<form class="form-horizontal" method="post" id="form1"
		enctype="multipart/form-data">
		<input type="hidden" name="idx" id="idx" value="${board.code}">

		<div class="form-group">
			<label for="name" class="col-sm-2 control-label">상품명 : </label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="name" placeholder="상품명"
					name="name" disabled="disabled" value="${board.name}">
			</div>
		</div>
		<div class="form-group">
			<label for="price" class="col-sm-2 control-label">가격 : </label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="price" placeholder="가격"
					name="price" disabled="disabled" value="${board.price}">
			</div>
		</div>
		<div class="form-group">
			<label for="content" class="col-sm-2 control-label">내용 : </label>
			<div class="col-sm-5">
				<textarea class="form-control" rows="3" id="content" name="content"
					disabled="disabled">${board.content}</textarea>
			</div>
		</div>

		<div class="form-group">
			<label for="fileUpload" class="col-sm-2 control-label">사진 : </label>
			<img src="../upload/${board.fileName}" id="photo" name="photo" />

		</div>
	
		<div class="form-group">
			<div class="col-sm-offset-2 col-sm-10" id="btnGroup">
				<button type="button" class="btn btn-default" name="edit" id="edit">수정</button>
				<button type="button" onclick="location.href='../board/list'"
					class="btn btn-primary">목록</button>
				<button type="button" class="btn btn-default" name="remove"
					id="remove">삭제</button>
			</div>
		</div>
	</form>


</body>
</html>