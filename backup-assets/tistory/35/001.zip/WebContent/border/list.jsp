<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>

<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt"%>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
<title>Bootstrap 101 Template</title>

<!-- Bootstrap -->
<link href="../css/bootstrap.min.css" rel="stylesheet">

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>

<body>
	<h1>게시판</h1>

	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
	<script src="../js/jquery.js"></script>
	<!-- Include all compiled plugins (below), or include individual files as needed -->
	<script src="../js/bootstrap.min.js"></script>



	<table class="table table-bordered">
		<tr>
			<th>번호</th>
			<th>제목</th>
			<th>가격</th>
			<th>등록날짜</th>

			<c:forEach var="list" items="${list}">
				<tr>
					<td>${list.code}</td>
					<td><a href="../board/detail?idx=${list.code}">${list.name}</a></td>
					<td>${list.price }</td>
					<td><fmt:formatDate value="${list.regDate}" pattern="yyyy-MM-dd"></fmt:formatDate></td>
				</tr>
			</c:forEach>
	</table>
	<form class="form-horizontal" action="../border/insert.jsp">
	<button type="submit" class="btn btn-primary">등록</button>
	</form>
	
	
</body>
</html>