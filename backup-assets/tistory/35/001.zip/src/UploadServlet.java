import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

@WebServlet("/upload")
public class UploadServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String savePath ="upload"; //다운로드 경로 설정
		int uploadFileSizeLimit = 5*1024 *1024; //파일 업로드의 최대 크기
		String enctype ="UTF-8"; //인코딩
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8"); 
		PrintWriter out = response.getWriter();
		//서버상의 실제 경로를 찾아내는 것
		ServletContext context = getServletContext();
		String uploadPath = context.getRealPath(savePath);
		System.out.println("서버상의 실제 디렉토리 : ");
		System.out.println(uploadPath);
		
		try {
			//request객체, uploadFilePath(서버상 실제 디렉토리), uploadFileSizeLimit(최대 업로드 파일크기), encType(인코딩방법), DefaultFileRenamePolicy()(동일이름이 존재하면 새로운 이름 부여됨) 
			MultipartRequest multi = new MultipartRequest(request, uploadPath,uploadFileSizeLimit,enctype, new DefaultFileRenamePolicy());
			//업로드된 파일 이름 얻기
			String fileName = multi.getFilesystemName("uploadfile");
			System.out.println("파일이름 :  " +fileName);
			if(fileName == null) {
				System.out.println("파일이 업로드 되지 않음");
			}
			else {
				out.println("<br> 글쓴이 : "+ multi.getParameter("name"));
				out.println("<br>제목 : "+ multi.getParameter("title"));
				out.println("<br> 파일명 : "+ fileName);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
