package com.study.board.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.study.board.persistence.dao.BoardDao;
import com.study.board.persistence.dto.Board;
import com.study.config.ApplicationFactory;

@WebServlet("/board/detail")
public class boardDetail extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int idx = Integer.parseInt(request.getParameter("idx"));

		ApplicationFactory factory = new ApplicationFactory();
		BoardDao dao = factory.boardDao();
		try {
			Board board = dao.search(idx);
		
			//request.setAttribute("path",path);
			request.setAttribute("board", board);
			RequestDispatcher dispatcher = request.getRequestDispatcher("../border/detail.jsp");
			dispatcher.forward(request, response);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

}
