package com.study.board.controller;

import java.io.File;
import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;
import com.study.board.persistence.dao.BoardDao;
import com.study.board.persistence.dto.Board;
import com.study.config.ApplicationFactory;

/**
 * Servlet implementation class boardInsert
 */
@WebServlet("/board/insert")
public class boardInsert extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String savePath = "upload";
		int uploadFileSizeLimit = 10 * 1024 * 1024;
		String encType = "UTF-8";

		ServletContext context = getServletContext();
		String uploadFilePath = context.getRealPath(savePath);
		ApplicationFactory factory = new ApplicationFactory();
		BoardDao dao = factory.boardDao();
		try {
			MultipartRequest multi = new MultipartRequest(request, uploadFilePath, uploadFileSizeLimit, encType,
					new DefaultFileRenamePolicy());

			String filename = multi.getFilesystemName("fileUpload");
			System.out.println("filename : "+filename);
			File file = multi.getFile("fileUpload");
			long filesize = file.length();
		
			System.out.println(filesize);
			if (filename == null) {
				response.sendRedirect("result.jsp?msg=false");
			} else {
				Board board = new Board();
				board.setContent(multi.getParameter("content"));
				board.setFileName(filename);
				board.setFileSize(filesize);
				board.setPrice(Integer.parseInt(multi.getParameter("price")));
				board.setName(multi.getParameter("name"));
				boolean flags = dao.insert(board);
				System.out.println("결과 :" + flags);
				if (flags == true) {

					response.sendRedirect("../border/result.jsp?msg=true");
				} else {
					response.sendRedirect("../border/result.jsp?msg=false");
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
