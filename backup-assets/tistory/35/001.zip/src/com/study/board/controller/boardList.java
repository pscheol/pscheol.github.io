package com.study.board.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.study.board.persistence.dao.BoardDao;
import com.study.board.persistence.dto.Board;
import com.study.config.ApplicationFactory;


@WebServlet("/board/list")
public class boardList extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ApplicationFactory factory = new ApplicationFactory();
		BoardDao dao = factory.boardDao();
		List<Board> list;
		try {
			list =dao.read();
			request.setAttribute("list", list);
			RequestDispatcher dispatcher = request.getRequestDispatcher("../border/list.jsp");
			dispatcher.forward(request, response);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}

}
