package com.study.board.controller;

import java.io.File;
import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;
import com.study.board.persistence.dao.BoardDao;
import com.study.board.persistence.dto.Board;
import com.study.config.ApplicationFactory;

/**
 * Servlet implementation class boardUpdate
 */
@WebServlet("/board/update")
public class boardUpdate extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int idx = Integer.parseInt(request.getParameter("idx"));
	
		
		String savePath = "upload";
		int uploadFileSizeLimit = 10*1024*1024;
		String encType= "UTF-8";
		
		ServletContext context = getServletContext();
		String uploadFilePath = context.getRealPath(savePath);
		ApplicationFactory factory= new ApplicationFactory();
		BoardDao dao = factory.boardDao();
		
		
		try {
			MultipartRequest multi = new MultipartRequest(request, uploadFilePath,uploadFileSizeLimit,encType,new DefaultFileRenamePolicy());
			
			String fileName = multi.getFilesystemName("fileUpload");
			File file =  multi.getFile("fileUpload");
			long filesize = file.length();
			
			String name = multi.getParameter("name");
			String content = multi.getParameter("content");
			int price = Integer.parseInt(multi.getParameter("price"));
			
			if(fileName == null) {
				response.sendRedirect("result.jsp?msg=false");
			}
			else {
				Board board = new Board(idx, name, price, fileName, filesize, content);
				boolean flags =dao.update(board);
				if(flags == true) {
					response.sendRedirect("../border/updateResult.jsp?msg=true");
				}
				else {
					response.sendRedirect("../border/updateResult.jsp?msg=false&idx="+idx);
				}
			}
		
		} catch (Exception e) {
			// TODO: handle exception
		}
		
	}

}
