package com.study.board.persistence.dao;

import java.sql.SQLException;
import java.util.List;

import com.study.board.persistence.dto.Board;
import com.study.config.DBConnector;

public interface BoardDao {

	public void setDataSource(DBConnector dataSource);
	public List<Board> read() throws SQLException;
	public boolean insert(Board board) throws SQLException ;
	public Board search(int idx) throws SQLException ;
	public boolean update(Board board) throws SQLException ;
	public boolean delete(int idx) throws SQLException;
}
