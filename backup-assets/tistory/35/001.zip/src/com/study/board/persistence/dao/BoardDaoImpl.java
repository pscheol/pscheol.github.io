package com.study.board.persistence.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.study.board.persistence.dto.Board;
import com.study.config.DBConnector;

public class BoardDaoImpl implements BoardDao {
	DBConnector dataSource = null;

	@Override
	public void setDataSource(DBConnector dataSource) {
		this.dataSource = dataSource;
	}

	public List<Board> read() throws SQLException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "";
		List<Board> list = null;
		try {
			list = new ArrayList<>();
			sql = "select * from board order by code desc";
			conn = dataSource.getConnection();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				Board board = new Board();
				board.setCode(rs.getInt("code"));
				board.setName(rs.getString("name"));
				board.setPrice(rs.getInt("price"));
				board.setContent(rs.getString("content"));
				board.setFileName(rs.getString("filename"));
				board.setFileSize(rs.getInt("filesize"));
				board.setRegDate(rs.getDate("filedate"));
				list.add(board);
			}

		} catch (Exception e) {
			if (conn != null) {
				rs.close();
				pstmt.close();
				conn.close();
			}
		} finally {
			dataSource.close(conn, pstmt, rs);
		}
		return list;
	}

	public boolean insert(Board board) throws SQLException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "";
		boolean flags = false;
		try {
			sql = "insert into board(name,price,filename,filesize,filedate,content) values(?,?,?,?,now(),?)";
			conn = dataSource.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, board.getName());
			pstmt.setInt(2, board.getPrice());
			pstmt.setString(3, board.getFileName());
			pstmt.setLong(4, board.getFileSize());
			pstmt.setString(5, board.getContent());
			if (1 == pstmt.executeUpdate()) {
				flags = true;
			}

		} catch (Exception e) {
			if (conn != null) {
				pstmt.close();
				conn.close();
			}
		} finally {
			dataSource.close(conn, pstmt);
		}
		return flags;
	}

	public Board search(int idx) throws SQLException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "";
		Board board = null;
		try {
			sql = "select * from board where code=?";
			conn = dataSource.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, idx);
			rs = pstmt.executeQuery();

			rs.next();
			board = new Board();
			board.setCode(rs.getInt("code"));
			board.setName(rs.getString("name"));
			board.setPrice(rs.getInt("price"));
			board.setContent(rs.getString("content"));
			board.setFileName(rs.getString("filename"));
			board.setFileSize(rs.getInt("filesize"));
			board.setRegDate(rs.getDate("filedate"));
		} catch (Exception e) {
			if (conn != null) {
				pstmt.close();
				conn.close();
			}
		}finally {
			dataSource.close(conn, pstmt, rs);
		}
		return board;
	}

	@Override
	public boolean update(Board board) throws SQLException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "";
		boolean flags = false;
		try {
			sql = "update board set name=? ,price =? , filename=?, filesize=?, filedate=now(), content=? where code =?";
			conn = dataSource.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, board.getName());
			pstmt.setInt(2, board.getPrice());
			pstmt.setString(3, board.getFileName());
			pstmt.setLong(4, board.getFileSize());
			pstmt.setString(5, board.getContent());
			pstmt.setInt(6, board.getCode());
			
			if (1 == pstmt.executeUpdate()) {
				flags = true;
			}

		} catch (Exception e) {
			e.printStackTrace();
			if (conn != null) {
				pstmt.close();
				conn.close();
			}
			
		} finally {
			dataSource.close(conn, pstmt);
		}
		return flags;
	}

	@Override
	public boolean delete(int idx) throws SQLException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "";
		boolean flags = false;
		try {
			sql = "delete from board where code=?";
			conn = dataSource.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, idx);
			
			if (1 == pstmt.executeUpdate()) {
				flags = true;
			}

		} catch (Exception e) {
			e.printStackTrace();
			if (conn != null) {
				pstmt.close();
				conn.close();
			}
			
		} finally {
			dataSource.close(conn, pstmt);
		}
		return flags;
	}
}
