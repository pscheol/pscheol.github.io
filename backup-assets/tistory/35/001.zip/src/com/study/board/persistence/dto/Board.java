package com.study.board.persistence.dto;

import java.sql.Date;

public class Board {
	private int code;
	private String name;
	private int price;
	private String fileName;
	private long fileSize;
	private Date regDate;
	private String content;
	
	
	public Board() {
		super();
	}
	public Board(int code, String name, int price, String fileName, long fileSize, String content) {
		super();
		this.code = code;
		this.name = name;
		this.price = price;
		this.fileName = fileName;
		this.fileSize = fileSize;

		this.content = content;
	}
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public long getFileSize() {
		return fileSize;
	}
	public void setFileSize(long fileSize) {
		this.fileSize = fileSize;
	}
	public Date getRegDate() {
		return regDate;
	}
	public void setRegDate(Date regDate) {
		this.regDate = regDate;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
}
