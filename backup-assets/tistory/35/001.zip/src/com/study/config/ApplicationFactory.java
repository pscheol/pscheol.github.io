package com.study.config;

import com.study.board.persistence.dao.BoardDao;
import com.study.board.persistence.dao.BoardDaoImpl;
import com.study.member.persistence.dao.MemberDao;
import com.study.member.persistence.dao.MemberDaoImpl;

public class ApplicationFactory {
	public MemberDao MemberDao() {
		MemberDao memberDao = new MemberDaoImpl();
		memberDao.setDataSource(dataSource());
		return memberDao;
	}
	public BoardDao boardDao() {
		BoardDao boardDao = new BoardDaoImpl();
		boardDao.setDataSource(dataSource());
		return boardDao;
	}
	private DBConnector dataSource() {
		return new DBConnector();
	}
}
