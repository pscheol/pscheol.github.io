package com.study.member.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.study.config.ApplicationFactory;
import com.study.member.persistence.dao.MemberDao;
import com.study.member.persistence.dto.Member;


@WebServlet("/login")
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
  

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String userid= request.getParameter("userid");
		String password= request.getParameter("password");
		ApplicationFactory factory = new ApplicationFactory();
		HttpSession session = null;
		MemberDao dao = factory.MemberDao();
		boolean userChk = dao.userChk(userid, password);
		if(userChk == true) {
			System.out.println("아이디 비번이 일치");
			Member member = dao.getMember(userid);
			session = request.getSession();
			session.setAttribute("member", member);
			request.setAttribute("msg", "로그인에 성공하였습니다.");
			RequestDispatcher dispatcher = request.getRequestDispatcher("index.jsp");
			dispatcher.forward(request, response);
		}
		else {
			System.out.println("일치하지않음");
			request.setAttribute("msg", "아이디 또는 비밀번호가 일치하지 않습니다");
			RequestDispatcher dispatcher = request.getRequestDispatcher("index.jsp");
			dispatcher.forward(request, response);
		}
		
	}
}
