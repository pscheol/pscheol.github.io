package com.study.member.persistence.dao;

import com.study.config.DBConnector;
import com.study.member.persistence.dto.Member;

public interface MemberDao {

	public void setDataSource(DBConnector dataSource);
	public boolean userChk(String userid,String password);
	public Member getMember(String userid);
}
