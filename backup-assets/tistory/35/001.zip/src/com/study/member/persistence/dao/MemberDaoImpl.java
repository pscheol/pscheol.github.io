package com.study.member.persistence.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.study.config.DBConnector;
import com.study.member.persistence.dto.Member;

public class MemberDaoImpl implements MemberDao{
	DBConnector dataSource;
	@Override
	public void setDataSource(DBConnector dataSource) {
		this.dataSource = dataSource;
	}
	public boolean userChk(String userid,String password) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		boolean isUseridChk = false;
		try {
			conn = dataSource.getConnection();
			String sql = "select userid, username from member where userid= ? and pwd=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userid);
			pstmt.setString(2, password);
			rs = pstmt.executeQuery();
			
			if(rs.next() == true) {
				isUseridChk= true;
			}
			else {
				isUseridChk = false;
			}
			
		} catch (Exception e) {
			dataSource.close(conn, pstmt, rs);
		}
		finally {
			dataSource.close(conn, pstmt, rs);
		}
		return isUseridChk;
	}
	public Member getMember(String userid) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Member member= null;

		try {
			conn = dataSource.getConnection();
			String sql = "select userid, pwd, username from member where userid= ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userid);
		
			rs = pstmt.executeQuery();
			
			if(rs.next() == true) {
				member = new Member();
				member.setUserId(rs.getString("userid"));
				member.setUserName(rs.getString("username"));
				member.setPassWord(rs.getString("pwd"));
			}
		} catch (Exception e) {
			dataSource.close(conn, pstmt, rs);
		}
		finally {
			dataSource.close(conn, pstmt, rs);
		}
		return member;
		
	}
}
